#!/bin/sh
#
# edit to fit your needs
cd /var/www/packages
./updater.php
/usr/bin/mysql < packages.sql -u YOURMYSQLUSER --password=YOURMYSQLPASS
