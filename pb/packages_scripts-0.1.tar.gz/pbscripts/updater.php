#!/usr/bin/php -c/var/www/packages/php.ini 
<?
/*

  Copyright (c) 2006, Slackware Linux, Inc.
  Author Andreas Liebschner <fizban@slackware.com
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in the 
      documentation and/or other materials provided with the distribution.
    * Neither the name of Slackware Linux, Inc. nor the names of its 
      contributors may be used to endorse or promote products derived from 
      this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.

 */

/* This is where all the magic happens. */

/* BEGIN OF CONFIG SECTION */
/* +-----------------------------------------+ */

/* we rely on an ftp site, and not on files stored locally. so.. */
$ftp_addr = "ftp.osuosl.org";
$ftp_path = "/pub/slackware";
$ftp_user = "anonymous";
$ftp_pass = "anon@slackware.com";  // maybe you should change this one

/* we use a .sql file that we will `mysql < $filename -u -p` somehow..
   it's probably better on the performance to use a mysql client instead 
   of making php mysql queries all over
   */
$sql = "packages.sql";

/* some of the array we use */
$arr_versions = array();
$arr_vers = array();
$arr_dry = array();
$arr_done_stuff = array();
$arr_changelogs = array();
$dome = "dome.txt";
$arr_dome = array();

/* there may be directories we are not interested in. */
$no_go = array("/pub/slackware/ls-lR", "/pub/slackware/ls-lR.gz", 
		"/pub/slackware/slackware", "/pub/slackware/slackware-3.3", 
		"/pub/slackware/slackware-1.1.2", "/pub/slackware/slackware-2.0.1",
		"/pub/slackware/slackware-2.1", "/pub/slackware/slackware-2.2.0",
		"/pub/slackware/slackware-2.3", "/pub/slackware/slackware-3.0",
		"/pub/slackware/slackware-3.1", "/pub/slackware/NB-SYNCING-FROM-SLACKWARE.COM",
		"/pub/slackware/slackware-3.4", "/pub/slackware/slackware-3.5",
	       	"/pub/slackware/slackware-3.6", "/pub/slackware/slackware-3.9",
	       	"/pub/slackware/slackware-4.0", "/pub/slackware/slackware-7.0",
	       	"/pub/slackware/slackware-7.1", "/pub/slackware/slackware-8.0",
	       	"/pub/slackware/slackware_source", "/pub/slackware/unsupported");

/* files and directories we will deal with */
$arr_files = array("MANIFEST.bz2", "PACKAGES.TXT", "CHECKSUMS.md5");
$arr_dirs = array("slackware", "extra", "testing", "patches", "pasture");

/* this is where we are going to store local copies of the files (and dirs) */
$local = "files/txtfiles";

/* END OF CONFIG SECTION */
/* +-----------------------------------------+ */


/* BEGIN OF FUNCTIONS AND STUFF */
/* +-----------------------------------------+ */

/* OK, we are done with config stuff for now, let's start with the 
   real functions! */

/* now we connect to the ftp site, and at the end, we'll have an array 
   populated with the slackware-$VER we found on the ftp site */

$conn_id = ftp_connect($ftp_addr) or die("Couldn't connect to $ftp_addr");
$login_result = @ftp_login($conn_id, $ftp_user, $ftp_pass);

if($login_result == FALSE) {                        // if we coundn't login, there's no 
                                                    // point in going on.
        die("Couldn't connect to ftp, dying.\n");
}

$mode = ftp_pasv($conn_id, TRUE);
$contents = ftp_nlist($conn_id, $ftp_path);

if($contents === FALSE) {                           // if we can't get a list of the files
                                                    // or directories.. we die
        die("Couldn't get the list of versions from ftp.\n");
}

for($i=0;$i<count($contents);$i++) {
   /* do not consider it if it's in $no_go (files/dirs blacklisted) */
   if(in_array($contents[$i], $no_go)) {
      continue;

   }

   /* we don't also give a shit about the -iso directories */
   if (ereg("iso", $contents[$i])) {
      continue;

   }

   /* we strip out the path prefix to obtain a clean slackware-version */
   $version = str_replace("$ftp_path/", "", $contents[$i]);
   array_push($arr_versions, $version);
   $ver = str_replace("slackware-", "", $version);
   array_push($arr_vers, $ver);

}


for($i=0;$i<count($arr_versions);$i++) {
   $curr_ver = $arr_versions[$i];
   
   
   if(!is_dir("$local/$curr_ver")) {    // this is for a dry run, or when a new version gets released
      mkdir("$local/$curr_ver", 0755);
   
   }

   if(!is_file("$local/$curr_ver/ChangeLog.txt")) {   // assume dry run, get everything right away
   //echo "dry run!\n";
   array_push($arr_dry, $curr_ver);
      @ftp_get($conn_id, "$local/$curr_ver/ChangeLog.txt", "$ftp_path/$curr_ver/ChangeLog.txt", FTP_BINARY);

      for($n=0;$n<count($arr_dirs);$n++) {
         $curr_dir = $arr_dirs[$n];
	 
	 if($curr_dir == "patches" AND $curr_ver == "slackware-current") {
	 } else {
	  
	    if(!is_dir("$local/$curr_ver/$curr_dir")) {
	        mkdir("$local/$curr_ver/$curr_dir", 0755);
	    }
	       
            @ftp_get($conn_id, "$local/$curr_ver/$curr_dir/MANIFEST.bz2", "$ftp_path/$curr_ver/$curr_dir/MANIFEST.bz2", FTP_BINARY);
            @ftp_get($conn_id, "$local/$curr_ver/$curr_dir/PACKAGES.TXT", "$ftp_path/$curr_ver/$curr_dir/PACKAGES.TXT", FTP_BINARY);
            @ftp_get($conn_id, "$local/$curr_ver/$curr_dir/CHECKSUMS.md5", "$ftp_path/$curr_ver/$curr_dir/CHECKSUMS.md5", FTP_BINARY);
	 
	    array_push($arr_done_stuff, "$curr_ver/$curr_dir");	       
	       
         }
      
      }
      
      if(is_file("$local/$curr_ver/ChangeLog.txt")) {	    
         array_push($arr_changelogs, "$curr_ver");

      }

   }
	 
   else {        // else, if the file is there, we just get it if the 
	         // local size is different from the remote

      if(filesize("$local/$curr_ver/ChangeLog.txt") != ftp_size($conn_id, "$ftp_path/$curr_ver/ChangeLog.txt")) {
      echo "$curr_ver changelog changed!\n";
      
         @ftp_get($conn_id, "$local/$curr_ver/ChangeLog.txt", "$ftp_path/$curr_ver/ChangeLog.txt", FTP_BINARY);

         for($n=0;$n<count($arr_dirs);$n++) {
            $curr_dir = $arr_dirs[$n];

	    if($curr_dir != "patches" || $curr_ver != "slackware-current") {
	    
               @ftp_get($conn_id, "$local/$curr_ver/$curr_dir/CHECKSUMS.md5.new", "$ftp_path/$curr_ver/$curr_dir/CHECKSUMS.md5", FTP_BINARY);
	    
	       if(md5_file("$local/$curr_ver/$curr_dir/CHECKSUMS.md5.new") != md5_file("$local/$curr_ver/$curr_dir/CHECKSUMS.md5")) {  // updates!

                  @ftp_get($conn_id, "$local/$curr_ver/$curr_dir/MANIFEST.bz2", "$ftp_path/$curr_ver/$curr_dir/MANIFEST.bz2", FTP_BINARY);
                  @ftp_get($conn_id, "$local/$curr_ver/$curr_dir/PACKAGES.TXT", "$ftp_path/$curr_ver/$curr_dir/PACKAGES.TXT", FTP_BINARY);
	          unlink("$local/$curr_ver/$curr_dir/CHECKSUMS.md5");
	          rename("$local/$curr_ver/$curr_dir/CHECKSUMS.md5.new", "$local/$curr_ver/$curr_dir/CHECKSUMS.md5");
	    
	          array_push($arr_done_stuff, "$curr_ver/$curr_dir");
	    
	       }
	    
	       else {
	          unlink("$local/$curr_ver/$curr_dir/CHECKSUMS.md5.new");
	    
	       }
	    
	    }

         }
      
      }
	       
      if(is_file("$local/$curr_ver/ChangeLog.txt")) {
         array_push($arr_changelogs, "$curr_ver");
		  
      }

   }

}

/* Riiiight. Now we have an array with the files we got from the ftp.
   These files are either new, or updated.. So we just use the data 
   in the array to re-populate our database. We won't fuck with anything 
   else.
   
   */

   // open up the $sql file and get ready to get naked *wink wink*
   $fp = fopen($sql, "w");
   
   fwrite($fp, "USE packages;\n");

for($i=0;$i<count($arr_dry);$i++) {
    $version = $arr_dry[$i];
    fwrite($fp, "INSERT INTO `tbl_versions` VALUES ('$version', '');\n");

}

for($i=0;$i<count($arr_done_stuff);$i++) {
   $line = $arr_done_stuff[$i];
   $tmp_arr = explode("/", "$line");
   
   $version = trim($tmp_arr[0]);
   
   if(!in_array($version, $arr_dome)) {
      array_push($arr_dome, $version);
   }
   $dir = $tmp_arr[1];
   
   echo "updates in $version/$dir.. parsing now\n";

   // delete the packages contained in the updated dir, in the updated ver
   fwrite($fp, "DELETE FROM `tbl_packages` WHERE `pkg_dir`='$dir' AND `ver_name`='$version';\n");
   

   /* FILELIST.TXT STUFF */
   
   $pwd = "$local/$version/$dir";
   
   /* now we add info about the packages to the db */
      
   $precon = file("$pwd/PACKAGES.TXT");
   array_splice($precon, 0, 10);
      
   $contents = explode("\n\n", trim(implode("",$precon)));
      
   for($int=0;$int<count($contents);$int++) {
      
      $temp = explode("\n", $contents[$int]);
      $pkg = str_replace(".tgz", "", str_replace("PACKAGE NAME:  ", "", $temp[0]));
      $subdir = str_replace("PACKAGE LOCATION:  ./$dir", "", $temp[1]);
      $compsize = str_replace("PACKAGE SIZE (compressed):  ", "", $temp[2]);
      $uncompsize = str_replace("PACKAGE SIZE (uncompressed):  ", "", $temp[3]);
      $stripout = substr($temp[5], 0 , strpos($temp[5], ':'));
      $temp = str_replace("$stripout: ", "", $temp);
      $temp = str_replace("$stripout:", "", $temp);
      
      array_splice($temp, 0, 5);
      
      $descr = addslashes(trim(implode("\n", $temp)));
      
      fwrite($fp, "INSERT INTO `tbl_packages` VALUES ('$pkg', '$dir', '$subdir', '$version', '$compsize', '$uncompsize', '', '$descr', '');\n");

   }


   /* CHECKSUMS.md5 STUFF  */

   $fn = "$pwd/CHECKSUMS.md5";
   
   $contents = file("$fn");
   
   for($n=0;$n<count($contents);$n++) {
      $line = $contents[$n];
      
      $md5 = substr($line, 0, strpos($line, ' '));
      
      if(!stristr($line, '/source')) {   // we don't care about stuff under ./source/
                                         // since we are a *package* browser...
      
         preg_match('/[a-zA-Z0-9_\.\+-\/]\/([^\/]*).tgz+$/', $line, $match);
      
         if($match[1]) {
            $pkg = $match[1];
	    
	    fwrite($fp, "UPDATE `tbl_packages` SET `pkg_md5sum`='$md5' WHERE `pkg_name`='$pkg' AND `ver_name`='$version';\n");

         }
      
      }
   
   }

   /* MANIFEST.bz2 STUFF */
   
   exec("/bin/bunzip2 -f -k $pwd/MANIFEST.bz2", $error);       // generally I hate executing local commands with a php script..
                                                                   // BUT, php's bzip2 functions suck and this script is supposed to
							           // be executed locally.. so
   $fn = "$pwd/MANIFEST";

   fwrite($fp, "DELETE FROM `tbl_files` WHERE `ver_name`='$version' AND `pkg_dir`='$dir';\n");
   
   $packages = explode("\n\n\n", file_get_contents("$fn"));        // we put the whole MANIFEST in an array 
	                                                           // splitted package per package
								   // passing from a  var.. any better solutions in 
								   // terms of resources and speed? because this
								   // one SUCK SO MUCH.

   for($int=0; $int<count($packages); $int++) {
      $arr_contents = explode("\n", $packages[$int]);

      if (!stristr($arr_contents[2], 'source')) {
         $inverted = strrev($arr_contents[2]);                     // if we invert the string we work easily
		                                                   // with it
			
	 $pkg = str_replace(".tgz", "", strrev(substr($inverted, 0 , strpos($inverted, '/'))));
	 
	 if(!$pkg) {                                           // if pkgname is empty dont even bother
	    continue;
	 }

	 $arr_files = array();
	
	 for($n=6; $n<count($arr_contents); $n++) {        // this is an hack to strip out 
			                                   // data we are not going to use
							   // and to obtain a clean filelist
							   // with the less stress on resources
	        
            $preFile = strrev($arr_contents[$n]);
	    $preFile = substr($preFile, 0, strpos($preFile, ' '));
	    $file = strrev($preFile);
	    array_push($arr_files, "/$file");

         }
	 
	 $filelist = implode("\n", $arr_files);             // we transform the filelist (array)
			                                    // in a variable before adding to mysql

	 fwrite($fp, "INSERT INTO `tbl_files` VALUES ('$pkg', '$dir', '$version', '$filelist');\n");

      }

   }

   unlink("$pwd/MANIFEST");   // just to avoid useless space usage (the .bz2 is still there)

}

fwrite($fp, "OPTIMIZE TABLE `tbl_packages`;\n");
fwrite($fp, "OPTIMIZE TABLE `tbl_files`;\n");



$fp_dome = fopen($dome, "w");

//$arr_dome = array_unique($arr_dome);

for($i=0;$i<count($arr_dome);$i++) {
   $version = $arr_dome[$i];
   echo "$version\n";
   fwrite($fp_dome, "$version\n");

}

?>
