<?php
$distro = 'slamd64';
$versions = array( # 'version' => 'directory name', most recent first
	'current' => 'current',
	'10.1' => '10.1-dvd'
	);
$hideDirs = array( NULL,
	'source',
	'isolinux',
	'kernels',
	'.',
	'..'
	);
$pkgExt = 'tgz';
$path = "/slamd64";

$fastMode = true; # if false, it's not just slow, it will also only return the first pack

# below only required for fastMode

$mysql_db = 'pb';
$mysql_user = 'pb';
$mysql_pass = 'pb';
$mysql_server = 'localhost';

$tmp = '/var/pb';
?>
