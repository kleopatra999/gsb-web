<?php
include 'config.inc.php';
if ( ! isset($_REQUEST['mode']) )
	$mode = 'home';
else
	$mode = $_REQUEST['mode'];
if ( preg_match('/[^a-z]/', $mode) )
	$mode = 'home';

function package_find_subdir($search, $verdir, $subdir, &$matchingPacks)
{
	include 'config.inc.php';
	$firstline = `grep -n "PACKAGE NAME" $path/$verdir/$subdir/PACKAGES.TXT | head -n 1 | cut -f 1 -d :`;
	$size = `wc -l $path/$verdir/$subdir/PACKAGES.TXT | awk '{print $1}'`;
	$packages = explode("\n\n", trim(shell_exec("tail -n " .
		($size - $firstline) . " $path/$verdir/$subdir/PACKAGES.TXT")));
	foreach ($packages as $package)
	{
		if ( ! preg_match("#^PACKAGE NAME:.+$search#", $package) )
			continue;
		$desc = "";
		$isDesc = false;
		foreach (explode("\n", $package) as $line)
		{
			if ( preg_match("#^PACKAGE NAME:#", $line) )
				{
					$name = substr($line, strpos($line, ":") + 3);
					$name = substr($name, 0, strrpos($name, ".")); # get rid of extension
					continue;
				}
			if ( preg_match("#^PACKAGE LOCATION:#", $line) ) # s/3/5/ for ./
				{ $location = substr($line, strpos($line, ":") + 5); continue; }
			if ( preg_match("#^PACKAGE SIZE \(compressed\):#", $line) )
				{ $compressed = substr($line, strpos($line, ":") + 3); continue; }
			if ( preg_match("#^PACKAGE SIZE \(uncompressed\):#", $line) )
				{ $uncompressed = substr($line, strpos($line, ":") + 3); continue; }
			if ( preg_match("#^PACKAGE DESCRIPTION:#", $line) )
			{ $isDesc = true; continue; }
			if ( $isDesc )
				$desc .= substr($line, strpos($line, ":") + 2) . "\n";
		}
		$matchingPacks[] = array(
			'name' => "$name",
			'location' => "$location",
			'compressed' => "$compressed",
			'uncompressed' => "$uncompressed",
			'desc' => "$desc"
			);
	}
}

function package_find($search, $verdir)
{
	include 'config.inc.php';
	$search = str_replace('+', '\+', $search);
	$matchingPacks = array();
	package_find_subdir($search, $verdir, '.', $matchingPacks);
	package_find_subdir($search, $verdir, 'extra', $matchingPacks);
	if ( file_exists("$path/$verdir/patches/PACKAGES.TXT") )
		package_find_subdir($search, $verdir, 'patches', $matchingPacks);
	if ( file_exists("$path/$verdir/testing/PACKAGES.TXT") )
		package_find_subdir($search, $verdir, 'testing', $matchingPacks);
	if ( file_exists("$path/$verdir/contrib/PACKAGES.TXT") )
		package_find_subdir($search, $verdir, 'contrib', $matchingPacks);
	return $matchingPacks;
}

// Print this, because otherwise php sees "<?" and thinks, "OOH! A ShortTag!"
print '<?xml version="1.0" encoding="iso-8859-1"?>';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Package Browser</title>
	<style type='text/css'>
<!--
pre {
	background-color: #CCCCCC;
	padding: 2px;
	border: 1px solid #888888;
}
.copyright {
	font-size: xx-small;
}
div {
	border: 2px solid black;
	margin: 1em;
	padding: 1em;
}
td.version, a {
	font-weight: bold;
}
a {
	color: #000000;
	text-decoration: underline;
}
//-->
	</style>
</head>
<body>
<h1>Package Browser</h1>

<?php if ( $mode == 'home' ) { ?>
<div>
<h2>Filename search:</h2>

<p>If you want to know which package contains a specific file you need, use the
following form.</p>

<form action='index.php' method='post'>
	<input type='hidden' name='mode' value='findfile' />
	<p>
		<select name='ver'>
<?php
foreach ($versions as $version => $dir)
	print "<option value='$version'>$distro-$version</option>\n";
?>
		</select>
		<select name='dir'>
			<option value='slackware'>slackware</option>
			<option value='patches'>patches</option>
			<option value='extra'>extra</option>
		</select>
		<input type='text' name='file' size='30' />
		<select name='wildcard'>
			<option value='on'>wildcard on</option>
			<option value='off'>wildcard off</option>
		</select><br />
		<input type='submit' value='search' />
	</p>
</form>

<h2>Package search:</h2>
<p>You can also look for a simple package!</p>
<form action='index.php' method='post'>
	<input type='hidden' name='mode' value='findpkg' />
	<p>
		<select name='ver'>
<?php
foreach ($versions as $version => $dir)
  print "<option value='$version'>$distro-$version</option>\n";
?>
		</select>
		<input type='text' name='package' size='30' />
		<input type='submit' value='search' />
	</p>
</form>
</div>
<div>
<table border='0' cellpadding='2px' >
<?php
foreach ($versions as $version => $dir )
{
print "<tr class='versionRow'>
	<td class='version'>$version</td>
	<td>
		[
		<a href='index.php?mode=browse&amp;ver=$version&amp;dir=slackware'>slackware</a>
		<a href='index.php?mode=browse&amp;ver=$version&amp;dir=extra'>extra</a>\n";
if ( file_exists("$path/$dir/patches") )
	print "<a href='index.php?mode=browse&amp;ver=$version&amp;dir=patches'>patches</a>";
else
	print "patches";
print "\n]\n</td>\n";
print "<td>(" . date("Y/m/d H:i T", filemtime("$path/$dir/CHECKSUMS.md5")) .
	")</td>\n";
print "</tr>";
}
?>
</table>
</div>
<?php
} # if ( $mode == 'home' )
if ( $mode == 'browse' ) {

if ( ! isset($_REQUEST['ver']) )
	header('location: index.php');
if ( preg_match('/[^a-z.0-9]/', $_REQUEST['ver']) )
	header('location: index.php');
if ( ! isset($_REQUEST['dir']) )
	header('location: index.php');
if ( preg_match('#[^a-z/]#', $_REQUEST['dir']) )
	header('location: index.php');
	
$ver = $_REQUEST['ver'];
if ( ! isset($versions["$ver"]) )
	header("location: index.php");
else
	$verdir = $versions["$ver"];
$dir = $_REQUEST['dir'];

if ( ! file_exists("$path/$verdir/$dir") )
	header('location: index.php');

if ( $dir == "" )
{
	print "<div>\n<h2>pwd: $distro-$ver/</h2>\n";
	print "<a href='index.php'>../</a><br />\n";
}
else
{
	print "<div>\n<h2>pwd: $distro-$ver/$dir/</h2>\n";
	strpos($dir, "/")
  	? $parentdir = preg_replace('#([^/]+)/[^\\\]+$#', '\1', $dir)
		: $parentdir = "";
	print "<a href='index.php?mode=browse&amp;ver=$ver&amp;dir=$parentdir'>../</a><br />\n";
}
$dh = opendir("$path/$verdir/$dir");
while ($filename = readdir($dh))
{
	if ( array_search($filename, $hideDirs))
		continue;
	$dir == ""
		? $link = $filename
		: $link = "$dir/$filename";
	$link = urlencode($link);
	if ( is_dir("$path/$verdir/$dir/$filename") )
		print "&nbsp;&nbsp;<a href='index.php?mode=browse&amp;ver=$ver&amp;dir=$link'>/$filename</a><br />\n";
	else
	{
		$parts = explode('.', $filename);
		$ext = $parts[sizeof($parts) - 1];
		if ( $ext == $pkgExt)
			print "&nbsp;&nbsp;<a href='index.php?mode=pack&amp;ver=$ver&amp;path=$link'>$filename</a><br />\n";
	}
}
print "</div>\n";
} # if ( $mode == 'browse' )
if ( $mode == 'findpkg' ) {
	if ( preg_match("#[^a-zA-Z0-9.\-_+]#", $_REQUEST['package']) )
		header('location: index.php');
	if ( ! isset($_REQUEST['ver']) )
	header('location: index.php');
	if ( preg_match('/[^a-z\.0-9]/', $_REQUEST['ver']) )
	  header('location: index.php');

	$search = $_REQUEST['package'];
	$ver = $_REQUEST['ver'];
	if ( ! isset($versions[$ver]) )
		header('location: index.php');
	$verdir = $versions[$ver];
	if ( ! file_exists("$path/$verdir/PACKAGES.TXT") )
		header('location: index.php');

  $matchingPacks = package_find($search, $verdir);

	print "<div>\n<p>Found " . sizeof($matchingPacks) . " matching packs:</p>\n";
	print "<ul>\n";
	foreach ($matchingPacks as $matchingPack)
	{
		$path = $matchingPack['location'] . '/' . $matchingPack['name'];
		print "<li><a href='index.php?mode=pack&amp;ver=$ver&amp;path="	
			. urlencode($path) . "'>$path</a></li>\n";
	}
	print "</ul>\n<p><a href='index.php'>Back</a></p>\n</div>\n";		
} # if ( $mode == 'findpkg' )
if ( $mode == 'findfile' )
{
	if ( ! isset($_REQUEST['ver']) )
	 header('location: index.php');
	if ( preg_match('/[^a-z\.0-9]/', $_REQUEST['ver']) )
	  header('location: index.php');
	if ( preg_match('/[^onf]/', $_REQUEST['wildcard']) )
		header('location: index.php');
	if ( preg_match('/[^a-zA-Z0-9_*?\\-.+]/', $_REQUEST['file']) )
		header('location: index.php');
	if ( preg_match('/[^a-z]/', $_REQUEST['dir']) )
		header('location: index.php');

	$dir = $_REQUEST['dir'];
	if ( $dir != "slackware" AND $dir != "extra" AND $dir != "patches" )
		header('location: index.php');
	$search = $_REQUEST['file'];
	$wildcard = $_REQUEST['wildcard'];
	
	$ver = $_REQUEST['ver'];
	if ( ! isset($versions[$ver]) )
		header('location: index.php');
	else
		$verdir = $versions[$ver];

	if ( $fastMode == false )
	{
		if ( ! file_exists("$path/$verdir/$dir/MANIFEST.bz2") )
			header('location: index.php');
		
		# MANIFEST.bz2 is _way_ to big to load in here... shell out to bzgrep methinks
		$string = str_replace(".", "\.", $search);
		if ( $wildcard == "on" )
		{
			$flag = "";
			$search = str_replace("*", ".\+", $search);
			$search = str_replace("?", ".", $search);
		}
		else
			$flag = "";
		$line = `bzgrep -ne "/$search$post" $path/$verdir/$dir/MANIFEST.bz2 | cut -f 1 -d :`;
		if ( $line == "" )
			print "<div><p>File not found.</p><p><a href='index.php'>Back</a></p></div>\n";
		else
		{
			$packlines = explode("\n", `bzgrep -n '||   Package:  ' $path/$verdir/$dir/MANIFEST.bz2`);
			$pack = "ERROR";
			foreach ($packlines as $packline)
			{
				if (substr($packline, 0, strpos($packline, ":")) + 0 > $line + 0)
					break;
				$pack = substr($packline, strrpos($packline, ":") + 5);
				$pack = substr($pack, 0, strrpos($pack, "."));
			}
			print "<div><p>Found in <a href='index.php?mode=pack&amp;ver=$ver&amp;path=" . 
				urlencode($dir/$pack) . "'>$dir/$pack</a>.</p><p><a href='index.php'>Back</a></p></div>\n";
		}
	} else {
		# Use MySQL instead of brute forcing it
		$link = mysql_connect(
			$mysql_server,
			$mysql_user,
			$mysql_pass);
		mysql_select_db($mysql_db);
		$sqlVer = str_replace('.', 'dot', $ver);
		if ( $wildcard == 'off')
			$result = mysql_query("SELECT * FROM $distro$sqlVer WHERE file LIKE '%/$search';");
		else
		{
			$search = str_replace('*', '%', $search);
			$search = str_replace('?', '_', $search);
			$result = mysql_query("SELECT * FROM $distro$sqlVer WHERE file like '%/$search';");
		}
		if (mysql_num_rows($result) == 0)
			print "<div><p>File not found.</p><p><a href='index.php'>Back</a></p></div>\n";
		else
		{
			print "<div><p>Found in " . mysql_num_rows($result) . " packs:</p><ul>\n";
			while ($row = mysql_fetch_assoc($result))
			{
				$pack = substr($row['package'], 0, strrpos($row['package'], '.'));
				print "<li><a href='index.php?mode=pack&amp;ver=$ver&amp;path=$pack'>$pack</a> - " .
					$row['file'] . "</li>\n";
			}
		}
		mysql_free_result($result);
		mysql_close($link);
		print "</ul>\n<p><a href='index.php'>Back</a></p></div>\n";
	}
} # if ( $mode == 'findfile' )
if ( $mode == 'pack' ) {
	if ( ! isset($_REQUEST['ver']) )
		header('location: index.php');
	if ( preg_match('/[^a-z\.0-9]/', $_REQUEST['ver']) )
		header('location: index.php');
	$ver = $_REQUEST['ver'];
	if ( ! isset($versions[$ver]) )
		header('location: index.php');
	$verdir = $versions[$ver];
	if ( ! isset($_REQUEST['path']) )
		header('location: index.php');
	if ( strstr('../', $_REQUEST['path']) )
		header('location: index.php');
	$filePath = $_REQUEST['path'];
	$fileName = substr($filePath, strrpos($filePath, "/") + 1);
	
	$matchingPacks = package_find($fileName, $verdir);
	if ( sizeof($matchingPacks) == 0 )
		print "<div><p>Error: invalid number of matching packs.</p><p><a href='index.php'>Back</a></p></div>\n";
	else
	{
		print "<div><h2>" . $matchingPacks[0]['name'] . "</h2>\n<p>
Location: $filePath.$pkgExt<br />
Compressed size: " . $matchingPacks[0]['compressed'] . "<br />
Uncompressed size: " . $matchingPacks[0]['uncompressed'] . "
</p>

<p><a href='index.php?mode=browse&amp;ver=$ver&amp;dir=" . substr($filePath, 0, strpos($filePath, $fileName) - 1) . "'>../</a></p>
	
<pre>" . trim($matchingPacks[0]['desc']) . "</pre>
</div>";
	}
} # if ( $mode == 'pack' )
?>
<hr />
<p class='copyright'>
Copyright &copy; 2005 <a href='http://www.fredemmott.co.uk'>Frederick Emmott</a>. Distributed under the GNU General Public License, Version 2.</p>
</body>
</html>
