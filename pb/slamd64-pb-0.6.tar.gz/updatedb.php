<?php
include 'config.inc.php';

function makeEntries($ver, $verdir, $dir, $link)
{
	$sqlVer = str_replace('.', 'dot', $ver);
	include 'config.inc.php';
	if (file_exists("$tmp/MANIFEST"))
		unlink("$tmp/MANIFEST");
	shell_exec("cd $tmp; cp $path/$verdir/$dir/MANIFEST.bz2 .; bunzip2 MANIFEST.bz2");
	$packLines = explode("\n", trim(`grep -n '||   Package:  ' $tmp/MANIFEST | cut -f 1 -d :`));
	for ($i = 0; $i < sizeof($packLines); $i++)
	{
		$pkgLN = $packLines[$i];
		$startLN = $packLines[$i] + 3;
		if ($i < sizeof($packLines) - 1)
			$endLN = $packLines[$i + 1] - 5;
		else
			$endLN = trim(`wc -l $tmp/MANIFEST | awk '{print $1}'`);
		$packLines[$i] = "";
		$fileList = shell_exec("head -n $endLN $tmp/MANIFEST | tail -n " .
			($endLN - $startLN + 1));
		$packLine = shell_exec("head -n $pkgLN $tmp/MANIFEST | tail -n 1");
		$pkgName = str_replace("||   Package:  ./", "$dir/", $packLine);
		foreach (explode("\n", $fileList) as $fileLine)
		{
			$file = substr($fileLine, strrpos($fileLine, ' ') + 1);
			mysql_query("insert into $distro$sqlVer (file, package) VALUES('" .
				mysql_real_escape_string("$file") . "', '" .
				mysql_real_escape_string("$pkgName") . "');");
		}
		unset($fileList);
		unset($packLine);
		unset($pkgLN);
		unset($startLN);
		unset($endLN);
	}
}

function recreate($ver, $verdir, $link)
{
	include 'config.inc.php';

	$sqlVer = str_replace('.', 'dot', $ver);

	mysql_query("DROP TABLE IF EXISTS $distro$sqlVer", $link);
	mysql_query("CREATE TABLE $distro$sqlVer (
		id bigint(20) NOT NULL auto_increment,
		file longtext,
		package longtext,
		PRIMARY KEY(id));", $link) or die("Could not create table: " . mysql_error() );

	# This is a strange way to do it, but stops a huge amount of memory
	# being used up at once
	if ( file_exists("$path/$verdir/slackware/MANIFEST.bz2") )
		makeEntries($ver, $verdir, 'slackware', $link);
	if ( file_exists("$path/$verdir/extra/MANIFEST.bz2") )
		makeEntries($ver, $verdir, 'extra', $link);
	if ( file_exists("$path/$verdir/patches/MANIFEST.bz2") )
		makeEntries($ver, $verdir, 'patches', $link);

	mysql_query("INSERT INTO $distro$sqlVer (file, package) VALUES
		('___MODIFIED___','" . filemtime("$path/$verdir/CHECKSUMS.md5") . "');");
}

$link = mysql_connect(
	$mysql_server,
	$mysql_user,
	$mysql_pass);
mysql_select_db($mysql_db) or die("Could not select database: " . mysql_error());
foreach ($versions as $ver => $verdir)
{
	$sqlVer = str_replace('.', 'dot', $ver);
	if ( ! mysql_query("select * from $distro$sqlVer limit 1") )
	{
		print "Doesn't exist: $ver\n";
		recreate($ver, $verdir, $link);
	}
	$result = mysql_query("select * from $distro$sqlVer where file = '___MODIFIED___'");
	if (mysql_num_rows($result) == 0)
	{	
		print "Invalid: $ver\n";
		recreate($ver, $verdir, $link);
	}
	else
	{
		$row = mysql_fetch_assoc($result);
		if ( $row['package'] + 0 < filemtime("$path/$verdir/CHECKSUMS.md5") + 0 )
		{
			print "Out of date: $ver\n\tIn db: " . $row['package'] . "\n\tIn tree: " . filemtime("$path/$verdir/CHECKSUMS.md5") . "\n";
			recreate($ver, $verdir, $link);
		}
	}
	mysql_free_result($result);
}
mysql_close($link);
?>
